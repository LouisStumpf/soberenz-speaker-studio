#!/usr/bin/env python3
"""Examples for loading, filtering, and searching the speech collection."""
import json
import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parent

with (root / "sobergenz_120_speeches.jsonl").open(encoding="utf-8") as stream:
    speeches = [json.loads(line) for line in stream]

print("Total speeches:", len(speeches))
print("Total words:", sum(s["word_count"] for s in speeches))

for speech in speeches:
    if speech["topic_id"] == "peer-pressure" and speech["audience_key"] == "high_school":
        print("\nMatching full speech:", speech["title"])
        print(speech["transcript"][:500] + "...")

with (root / "sobergenz_speech_chunks.jsonl").open(encoding="utf-8") as stream:
    chunks = [json.loads(line) for line in stream]
print("Total ready-to-embed chunks:", len(chunks))

connection = sqlite3.connect(root / "sobergenz_120_speeches.sqlite")
results = connection.execute("""
    SELECT s.id, s.title
    FROM speech_search f
    JOIN speeches s ON s.id = f.id
    WHERE speech_search MATCH ?
    ORDER BY bm25(speech_search)
    LIMIT 5
""", ("longevity",)).fetchall()
print("SQLite results for longevity:", results)
connection.close()
