#!/usr/bin/env python3
"""Build a searchable collection of 120 first-person SoberGenZ speech scripts.

Run: python3 build_database.py
Requires only the Python standard library. Output: JSONL, JSON, SQLite.
"""
from __future__ import annotations
import json
import re
import sqlite3
import hashlib
from pathlib import Path
from datetime import date

ROOT = Path(__file__).resolve().parent
ORG = "SoberGenZ"

# Each topic supplies an original central argument, thought experiment, and
# practical takeaway. These can be recombined for distinct delivery settings.
TOPICS = [
  {
    "slug": "reward-and-choice", "title": "The Brain, Reward, and the Choices We Make", "tags": ["neuroscience", "reward", "decision-making"],
    "hook": "I want to start with a question. Why can something feel rewarding in the moment and still be a bad trade for the person you want to become? That sounds like a contradiction until we talk about how the brain learns.",
    "idea": "Our brains pay attention to rewards. A joke that makes the room laugh, a message from someone we like, winning a match, finishing a difficult problem: those moments teach us what to seek again. Dopamine is involved in learning about motivation and reward, but it is not a magic happiness chemical. The important point is that a rewarding feeling is a signal, not a verdict. We can notice a signal without treating it as an instruction. Alcohol can affect judgment, coordination, and the way we process rewards. That matters especially when social expectations are strong, because the brain is reacting to two things at once: what the substance does and what being accepted by the group seems to promise. I do not want you to walk away thinking the brain makes our decisions for us. I want you to see that learning how it works gives us more room to decide.",
    "example": "Imagine someone standing at a gathering, holding a cup they did not really want. They look around. Everyone seems comfortable. They assume everyone else is more experienced. But maybe three other people in that room are also copying what they think everyone expects. The first person is not just making a decision about a drink. They are making a decision about whether uncertainty is allowed to show. If they knew that the feeling of being watched would pass, would they make the same choice? If they had a friend who said, 'I'm good with water,' would the whole scene change? One small choice can change what everybody else believes is normal.",
    "practice": "Here is the exercise I would actually like you to remember. When something feels urgent, name the reward you are chasing. Is it relief, belonging, excitement, curiosity, or simply avoiding an awkward conversation? Then ask if the action in front of you is the only way to get that reward. If you want belonging, call a friend over. If you want relief, step outside, breathe, or talk to someone you trust. If you want excitement, help make the gathering interesting. You are allowed to pursue a good feeling without handing over control of the process.",
    "close": "The brain is incredibly good at learning patterns. The question is not whether you will develop patterns. You will. The question is which patterns you want to teach it. Next time you feel pulled by a reward, give yourself a few seconds to choose what deserves repeating."
  },
  {
    "slug": "peer-pressure", "title": "What Peer Pressure Really Sounds Like", "tags": ["peer-pressure", "social-skills", "boundaries"],
    "hook": "When people hear the words peer pressure, they picture someone shouting, 'Do it!' But most pressure is quieter than that. Often nobody says anything at all.",
    "idea": "Pressure can be a pause after you say no, a joke about being boring, or the feeling that everyone else has received a rulebook you missed. People are social learners. We scan faces, copy behavior, and try to avoid rejection. Those instincts can help us cooperate, but they also make it easy to confuse a group's loudest behavior with the group's actual values. Your friends might not be asking you to drink. You might simply be assuming that they need you to. One reason this matters in alcohol prevention is that a personal choice can become a public performance. A young person stops asking, 'What do I want?' and starts asking, 'What will they think of me?' That is a very different question. It gives strangers and acquaintances a level of influence they have not earned.",
    "example": "Picture a friend saying, 'Come on, just one.' There are at least four possible stories behind those three words. They might think they are being friendly. They might be uncomfortable being the only person drinking. They might want a shared experience. Or they might simply be repeating a phrase they heard before. You do not need to solve their psychology in that moment. You only need an answer that protects your choice without starting a debate. 'No thanks, I'm good.' 'I'm staying clear-headed tonight.' 'Actually, I want to remember this.' A calm sentence often gives the conversation permission to move on.",
    "practice": "Let's rehearse something practical. Think of a situation where you may feel watched: a party, a sports celebration, a birthday, a group chat, even a family event. Come up with your one-sentence answer before you arrive. It should sound like you, not like a poster. Then think of one person who will respect that answer. You can agree in advance to back each other up. The most powerful kind of social confidence is not being able to win an argument. It is being comfortable enough that you do not need to have one.",
    "close": "You do not need to judge anyone else to set a boundary. And you do not need everyone to approve of your boundary for it to count. The next time the room feels loud, remember that your own voice is allowed to be quiet and firm."
  },
  {
    "slug": "first-decisions", "title": "The First Decision Is Not the Smallest", "tags": ["prevention", "risk", "choices"],
    "hook": "Some choices announce themselves as important. Others arrive disguised as a tiny moment: a hand offering you something, a friend asking you to join in, a decision made while laughing.",
    "idea": "We tend to evaluate risky choices as isolated events. Will I be fine this one time? Will anyone notice? What is the big deal? But people do not live in isolated events. Experiences create stories about ourselves. We remember what felt easy, what attracted praise, and what helped us escape discomfort. That does not mean one mistake defines a person. It means that early choices deserve attention precisely because they can feel so ordinary. With alcohol, the immediate environment can make long-term considerations seem distant. It can impair judgment and physical coordination, and consequences depend on many things, including how much someone consumes and the circumstances. The useful response is neither panic nor pretending no risks exist. It is learning to ask better questions before the pressure of the moment arrives.",
    "example": "Imagine tomorrow-morning-you sitting across the table from tonight-you. Tomorrow-morning-you has classes, friends, family, goals, maybe training or a project that matters. Tonight-you is trying to decide whether to impress someone for twenty seconds. Now make them have an actual conversation. What would tomorrow-morning-you say? Not necessarily, 'Never have fun.' More likely, 'Please do not trade my morning, my safety, and my peace of mind for the approval of someone who will barely remember the moment.' That's a way to make the future less abstract.",
    "practice": "Before a social event, decide on two things: what you are comfortable with, and how you will leave if the setting stops feeling comfortable. You do not have to share the plan with everybody. Tell one trusted person, charge your phone, and know who you can ask for help. If you change your mind about being somewhere, you can leave. A good decision is not proof that you can control every outcome. It is proof that you took the outcomes seriously.",
    "close": "A first choice does not write your entire story. But it can be a chance to practice being the author. You are much more interesting than any single thing you agree to do because someone else expects it."
  },
  {
    "slug": "stress", "title": "Stress Is Real; Escape Is Not a Strategy", "tags": ["stress", "coping", "mental-wellbeing"],
    "hook": "I do not want to talk about healthy choices as if everyone is having an easy week. Some of you are tired, anxious, angry, or carrying a problem nobody in this room knows about.",
    "idea": "Stress is not a sign of weakness. It is a real response to challenges, uncertainty, and sometimes situations we cannot control. Our bodies and minds are built to react to it. The problem begins when we confuse changing how we feel for a short time with changing the problem itself. Alcohol may be presented as a shortcut to relaxation, but relying on a substance to handle difficult emotions can bring additional risks and make it harder to practice coping skills. I want to draw a line between relief and recovery. Relief is the volume turning down briefly. Recovery is building the conditions that help you handle tomorrow. Recovery might include sleep, meaningful relationships, movement, professional support, or changing something about the pressure you are under. Those things can look less dramatic, but they are skills you can take with you.",
    "example": "Think of a phone with twenty applications running at the same time. The device gets hot and slows down. If you cover the screen, you stop seeing the problem but do not reduce the load. People sometimes do the emotional equivalent. We distract ourselves until we are numb, then wonder why everything feels just as heavy the next morning. The better question is which application needs to close. Are you exhausted? Are you avoiding a conversation? Have you asked for help? Are you expecting perfection from yourself? Naming the source of pressure is not always enough, but it is often the start of a more useful response.",
    "practice": "Try a three-part reset the next time things feel overwhelming. First, check your body: have you eaten, drunk water, and rested? Second, check your environment: can you step away from the noise or break a task into one small action? Third, check your connections: is there a trusted person, counselor, family member, or professional who could help? If something feels unsafe or unmanageable, seeking immediate support is a strong decision. The point is not to do everything alone. The point is to have more than one tool.",
    "close": "You deserve ways to feel better that do not make your problems bigger. A healthy life is not a life without stress. It is a life where stress does not get to make every decision."
  },
  {
    "slug": "sleep", "title": "Sleep Is a Competitive Advantage", "tags": ["sleep", "learning", "health"],
    "hook": "I want to defend something that almost never gets applause: going to sleep at a sensible time. In a culture that rewards being busy, rest can look like doing nothing.",
    "idea": "But sleep is active work. It supports learning, emotional regulation, attention, and the systems that help us recover from the day. Think about the difference between studying for another exhausted hour and waking up able to understand what you already learned. We often treat sleep as the leftover part of a schedule. It deserves to be part of the schedule itself. Alcohol can disrupt sleep quality even if someone feels drowsy after drinking, and it can add risks to an already tired mind. None of this means you must follow a perfect routine. It means that your brain needs conditions in which it can do its job. If you care about exams, creativity, sports, relationships, or simply not feeling awful in the morning, sleep belongs in the conversation.",
    "example": "Imagine two versions of the same student. Both are ambitious. Both have an important exam and a friend inviting them out. One thinks, 'I can always make up sleep later,' and treats exhaustion as evidence of commitment. The other plans the evening around getting home safely and recovering. A month later, which one is more likely to feel steady, remember information, and have energy for people they care about? This is not about the occasional late night. It is about recognizing the hidden cost of making tiredness your normal state.",
    "practice": "A practical experiment is to choose one week and protect a consistent wind-down window. Put the phone a little farther away, reduce stimulation when possible, and notice how your mornings change. If life makes a regular schedule difficult, work with what is realistic rather than abandoning the idea. Ask yourself, 'What is the smallest change that gives tomorrow-me a better starting point?' Sometimes prevention does not look like refusing a substance. It looks like building a life you do not constantly need to recover from.",
    "close": "There is nothing boring about being capable of showing up fully. Rest is not the opposite of ambition. It is one of the things that makes ambition sustainable."
  },
  {
    "slug": "memory", "title": "Your Memory Is Worth Protecting", "tags": ["memory", "attention", "neuroscience"],
    "hook": "I want you to think of a memory you would be genuinely upset to lose. Maybe it's a family dinner, a match, a birthday, or one random conversation that changed your life.",
    "idea": "Memory is not a video recording that captures everything perfectly. Your brain selects, connects, and reconstructs information, and attention plays an important role in what you remember. Experiences become meaningful partly because you were present enough to notice them. Alcohol can interfere with memory formation, especially at higher levels of intoxication, and that is not the same as simply forgetting a detail. People sometimes make jokes about not remembering an entire night. I want to challenge that joke. A night you cannot remember is not automatically a better night. Being able to tell the story afterward is part of what makes an experience yours. You can care about friends, music, celebration, and adventure while also caring about the ability to remember them.",
    "example": "Picture a reunion ten years from now. Your friends are describing the ridiculous dance someone invented, the speech a shy person finally gave, or the moment your team celebrated together. One person says, 'I have no idea; I don't remember.' Another can add the tiny detail that makes everybody laugh. Neither person's value is defined by the memory, but the difference raises a question: why are we sometimes encouraged to treat the loss of awareness as the price of belonging? If a moment is worth showing up for, perhaps it is worth staying present for.",
    "practice": "At your next social event, try collecting details on purpose. Notice who looks left out. Ask one question you have never asked a friend. Pay attention to a song, a room, or a funny exchange. Afterward, write down three things you want to remember. This is not a rule about how to have fun. It is a reminder that being alert and engaged is not a lesser version of the experience. It can be the richer one.",
    "close": "We often talk about protecting the future. I also want you to protect the present. Your memories are the material from which you build your story. Give yourself the chance to keep them."
  },
  {
    "slug": "belonging", "title": "Belonging Without Performing", "tags": ["belonging", "friendship", "identity"],
    "hook": "We spend so much time trying to fit into groups that we sometimes forget to ask whether the group is a place where we can actually be ourselves.",
    "idea": "Belonging is a human need, not a silly teenage insecurity. We all want to be seen, included, and respected. But belonging becomes fragile when it depends on performing a version of ourselves that gets approval. If you feel that you have to drink, pretend to enjoy something, laugh at a cruel joke, or hide your discomfort to stay welcome, that is important information about the situation. It does not mean everyone involved is a bad person. It means the social bargain deserves examination. SoberGenZ is not about replacing one form of judgment with another. It is about widening the number of ways a young person can belong. A good community should make it easier to make thoughtful choices, not harder.",
    "example": "Think about the most secure friendship you have. There is probably a moment when you do not have to entertain the other person. You can be tired. You can disagree. You can say, 'I'm not feeling it tonight,' and the friendship does not disappear. Now compare that with a room where you are constantly watching your reactions. Which place actually feels free? The difference is not whether people are having fun. The difference is whether you are allowed to be honest. We should be building more rooms where honesty is not punished.",
    "practice": "This week, test the quality of belonging in a small way. Invite someone who is often excluded. Suggest an activity that does not depend on alcohol. Back up a friend who declines something, and do it without making them a spectacle. If someone says no, respond as though it is perfectly ordinary, because it should be. You can create social permission for people you will never even know were nervous. Culture changes through the tiny interactions that tell people what is safe to be.",
    "close": "I want you to have friends with whom you can be interesting, awkward, ambitious, quiet, and fully yourself. The right group will not require you to lose your judgment to earn your place."
  },
  {
    "slug": "saying-no", "title": "How to Say No Without a Speech", "tags": ["communication", "boundaries", "refusal-skills"],
    "hook": "Here's an uncomfortable truth: sometimes the healthiest sentence you can say is just two words, and those two words feel surprisingly difficult. 'No, thanks.'",
    "idea": "People often imagine that setting a boundary requires a courtroom-quality argument. It doesn't. You do not need to prove your grades, explain your family, describe your medical history, or announce your values every time you decline a drink or an invitation. A boundary is information about what you are willing to do, not an essay about why another person is wrong. Being concise can actually protect relationships because it prevents a simple choice from turning into a debate. Some people will ask again because they did not hear you. Others will push because they dislike being disagreed with. You are allowed to repeat yourself. If pressure continues, you are allowed to change the setting or ask a friend for backup.",
    "example": "Let's compare two responses. The first is a ten-minute apology: 'I'm so sorry, it's just that I have an early morning, and my parents, and this project...' Every new reason creates another place for someone to argue. The second is calm: 'I'm all set, but tell me about your week.' The first says you are asking for an exception. The second says you have made a choice and are still willing to be social. Of course the best wording depends on the situation. The principle is that you do not owe endless explanations.",
    "practice": "Try three versions out loud. Friendly: 'I'm good, thanks.' Direct: 'No, I don't want that.' Exit: 'I'm going to head out.' Notice that none of them attack the other person. Practice the tone, not only the words. If someone is trying to control or intimidate you, do not prioritize sounding polite over getting to a safer place. A good friend can help, and adults or emergency services may be necessary when someone is in danger.",
    "close": "Confidence is not always a big dramatic moment. Sometimes it is a small sentence spoken clearly. You can respect other people while respecting yourself."
  },
  {
    "slug": "friend-safety", "title": "A Good Friend Notices", "tags": ["bystander", "friendship", "safety"],
    "hook": "I want to change the definition of a good night out. Not just: Did we have fun? Also: Did everybody get home safe, and did we look after each other?",
    "idea": "Friendship comes with a kind of responsibility that we do not always discuss. It is easy to celebrate friends when they are funny or exciting. It is harder, and more important, to notice when they are uncomfortable, isolated, or unable to make safe decisions. Alcohol can impair judgment, and serious intoxication can be a medical emergency. Looking out for someone does not mean pretending to be a doctor or taking risks yourself. It means being willing to act: get help from a responsible adult, event staff, or emergency services when needed, and do not leave a vulnerable person alone. It also means respecting people's boundaries when they are fully able to express them, rather than treating friendship as a license to control them.",
    "example": "Imagine the end of a celebration. The music is still playing, but one person has stopped responding normally, another is pressuring somebody to leave with them, and everybody else is busy taking photos. In that moment the group needs fewer spectators and more people who will pay attention. Someone can call for help. Someone can stay with the person until trained help arrives if it is safe to do so. Someone can interrupt the pressure and get a trusted adult involved. Courage can look very ordinary: putting your phone down and saying, 'We need to deal with this now.'",
    "practice": "Before an event, agree on an easy check-in. Know how to contact each other and where to ask for help. Never drive impaired or ride with someone who is impaired. If a person is unconscious, having difficulty breathing, having seizures, or cannot be awakened, call emergency services immediately. Do not assume they can simply sleep it off. The goal is not to scare you away from friendship; it is to show that caring for friends has practical meaning.",
    "close": "The most impressive person in a room is not always the one drawing the biggest crowd. Sometimes it is the one who notices that somebody needs help and quietly does the right thing."
  },
  {
    "slug": "risk-perception", "title": "Why Smart People Misjudge Risk", "tags": ["risk-literacy", "critical-thinking", "decisions"],
    "hook": "If being intelligent automatically made us good at decisions, nobody would ever procrastinate, take shortcuts, or do something just because their friends were doing it.",
    "idea": "We have a habit of judging a choice by what happened last time rather than by what could reasonably happen. Someone says, 'I did it before and nothing bad happened,' and treats that as proof the situation is harmless. But a good outcome does not always mean a good decision was made, just as a difficult outcome does not automatically mean someone was careless. Risk involves uncertainty. The environment, the person's condition, and other people's actions all matter. With alcohol, one gathering may seem uneventful while another introduces serious consequences. Prevention is not about predicting the exact future. It is about noticing factors that increase or reduce risk and making choices that leave less to luck.",
    "example": "Think about crossing a road while looking at your phone. If you reach the other side safely ten times, have you proved it is a safe habit? Of course not. You have just had ten outcomes. Now translate that reasoning to social situations. 'Everybody does it.' 'My friend was fine.' 'I know my limit.' These are statements worth examining, not guarantees. We become better decision-makers when we stop confusing confidence with information. The strongest thinkers are often the ones willing to say, 'I don't know enough, so I am going to be careful.'",
    "practice": "Ask three questions before a choice with consequences: What do I know, what am I assuming, and what happens if my assumption is wrong? Then ask whether there is a lower-risk way to get the thing you actually want. You can want connection without taking every social risk. You can want excitement without ignoring basic safety. You can be curious and still decide to wait. Treat uncertainty as a reason to think, not as a reason to surrender the decision.",
    "close": "You will never be able to remove uncertainty from life. But you can refuse to mistake luck for a strategy. That one habit will help you far beyond this conversation."
  },
  {
    "slug": "advertising", "title": "Who Is Selling You the Story?", "tags": ["marketing", "media-literacy", "alcohol-culture"],
    "hook": "Think about the last advertisement that made you want something. Usually it did not begin by giving you a spreadsheet. It gave you a feeling.",
    "idea": "Marketing often attaches products to emotions: friendship, freedom, attractiveness, success, adventure. The ad is not necessarily selling the chemistry of a product. It is selling an imagined version of a life. We should learn to separate the object from the story around it. When alcohol is connected to celebration or confidence, ask what is really making the scene appealing. Is it the drink, or is it the music, the people, and the invitation to belong? That question matters because young people can start to treat a commercial image as a social instruction. Media literacy is not refusing to enjoy art or entertainment. It is being able to enjoy the story while knowing that someone made choices about what to show and what to leave outside the frame.",
    "example": "Imagine you have two photographs from the same gathering. One shows a perfect sunset, people laughing, and glasses raised together. The other shows the same group an hour later, arguing over how to get home. An advertisement would have a strong incentive to choose the first image. Real life contains both the photogenic moments and the consequences. The purpose of noticing this is not to become cynical. It is to remember that the scene on a screen has been edited. Your actual life has to be lived in full, including the parts nobody posts.",
    "practice": "For the next week, when you see an ad, music video, or social post featuring alcohol, ask four questions. Who benefits from this image? Which emotion is being sold? Whose experience is missing? What other way could a person get the same positive emotion? Try the same exercise with any product marketed to young people. Once you can see the frame around a message, it becomes easier to decide how much influence the message deserves.",
    "close": "Do not outsource your idea of a good life to whoever is best at making a thirty-second video. Your definition of a great evening gets to be your own."
  },
  {
    "slug": "social-norms", "title": "Everybody Does It, Except They Don't", "tags": ["norms", "misperceptions", "peer-pressure"],
    "hook": "Three words can make people act against their preferences: 'Everybody does it.' I want to know who this mysterious everybody is.",
    "idea": "A visible minority can sometimes shape our picture of an entire group. The loudest people take up more space in our attention; the quiet people are harder to count. In school, at university, and online, we can overestimate how common a behavior is because examples of that behavior are memorable. Alcohol-related pressure can grow out of that error. If each person believes everyone else wants to drink, people may participate simply to avoid standing out. The remarkable thing is that not everyone has to change privately before the atmosphere changes publicly. Sometimes one honest sentence corrects a false assumption for several people at once. This is why having different ways to socialize is a genuine public-health issue, not just a personal preference.",
    "example": "Imagine ten people deciding what to do on Friday. Two enthusiastically suggest an alcohol-centered party. Three are unsure. Four would rather go somewhere else, and one person has an early start. Nobody wants to be the boring one. If the conversation ends after the first two voices, the group appears unanimous. Now imagine someone asks, 'Actually, what does everybody want?' Suddenly there are several possible plans. The facts in the room have not changed. The information has. A group is often much more flexible than its loudest moment makes it seem.",
    "practice": "Whenever you hear a claim about what 'everyone' does, ask for a real source or a more precise statement. Who, where, and in what situation? When planning an event, offer at least one appealing option that does not revolve around drinking. Make it genuinely fun rather than treating it as a punishment. You do not need to persuade anyone through shame. You can simply help people see that there are more choices than the group initially imagined.",
    "close": "If you have ever secretly wondered whether you are the only one who feels a certain way, there is a very good chance you are not. Sometimes being the first to say it is the most useful thing you can do."
  },
  {
    "slug": "celebration", "title": "How to Celebrate Without Losing the Point", "tags": ["celebrations", "social-design", "community"],
    "hook": "Think of your best celebration. I bet the part you remember is not the object someone was holding. It is how the people around you made you feel.",
    "idea": "Humans need rituals. We celebrate victories, birthdays, graduations, and tiny achievements because rituals tell us that a moment matters. In many places, alcohol has become attached to those rituals so closely that people assume the two are inseparable. But a celebration is something a community creates. It needs meaning, attention, and a reason to gather, not necessarily a substance. When we make alcohol the organizing principle, we can unintentionally exclude people who do not drink, cannot drink, do not want to drink, or simply want a different kind of evening. The creative challenge is not removing joy. It is designing joy intentionally. The best hosts think about music, activities, food, accessibility, safety, and whether people feel welcome.",
    "example": "Imagine a group celebrating the end of exams. One plan is 'everyone come over and we'll figure something out.' Another includes a ridiculous awards ceremony, a shared playlist, a midnight walk in a safe area, a photo wall, and a rule that everyone has to nominate someone else for a funny achievement. Which one is more likely to create a story people tell again? There is no universal answer, but the second plan demonstrates something important: culture is built, not discovered. We can put effort into what makes gatherings meaningful instead of relying on one product to generate the atmosphere.",
    "practice": "If you are organizing an event, give every person something to do besides hold a drink. Build in a moment when everyone can contribute. Offer appealing nonalcoholic options without making them a separate category of guests. Think about transport and how someone can leave comfortably. Most importantly, ask whether a new person could walk in and feel included. That is a much more ambitious goal than simply making a gathering look exciting from the outside.",
    "close": "A great celebration should leave people with more connection, more stories, and more energy for what comes next. Keep the meaning. Make the format your own."
  },
  {
    "slug": "sports", "title": "Performance Is Built Between Practices", "tags": ["sports", "recovery", "sleep"],
    "hook": "Athletes understand something the rest of us sometimes forget: what you do away from the main event changes what happens during it.",
    "idea": "Performance is not a single spectacular effort. It is a series of ordinary decisions about training, recovery, nutrition, sleep, and consistency. A person can practice hard and still undermine that work by ignoring the conditions their body needs. Alcohol can impair coordination and judgment, and drinking can interfere with recovery and sleep. The practical question is not whether one imperfect weekend destroys an athlete. It does not. The question is whether your routine is aligned with what you say you care about. I like the athlete's mindset because it brings prevention out of the category of moral rules and into the category of performance choices. You evaluate the trade-off, decide what matters, and take responsibility for how you prepare.",
    "example": "Picture two teammates with similar talent. One stays focused only on the visible part of the game, the training sessions and big matches. The other takes a serious interest in how they sleep, how they handle stress, and how they support teammates. A year later, the difference may not be one dramatic decision. It may be hundreds of slightly better decisions. We cannot guarantee the outcome of a season, but we can choose which habits support the chance to do our best. The same logic applies to performing on stage, preparing for exams, or building a company.",
    "practice": "Ask yourself what your equivalent of training is. What activity deserves a healthy, attentive version of you? Then work backward. Which routine supports it? Which social situations make it harder? Which friends help you protect it? Make one small agreement with yourself this week that you can actually keep. A commitment you repeat is worth much more than a grand promise you forget after a day.",
    "close": "Discipline is not about rejecting every enjoyable thing. It is about not sacrificing something important for a reward that matters less. Play the long game with your own potential."
  },
  {
    "slug": "longevity", "title": "A Long Life Starts With a Daily Life", "tags": ["longevity", "preventive-health", "habits"],
    "hook": "We hear enormous promises about the future of health: advanced technology, new treatments, and ways to live longer. I think there is a question we should ask before all of that: how are we living today?",
    "idea": "Longevity is not just counting the years at the end of a life. It is caring about the quality of the years in between: the ability to think clearly, move, connect, recover, and participate in things that matter. There is no single shortcut to that. Health depends on many factors, including circumstances people cannot fully control. But everyday habits can still help build a better foundation. Sleep, activity, nutrition, social relationships, preventive care, and avoiding unnecessary harms belong in the same conversation. Reducing alcohol-related risk is part of that broader picture. I do not want to turn every choice into a terrifying prediction about the future. I want to make health feel relevant before people reach a point when they wish they had paid attention.",
    "example": "Imagine meeting yourself twenty years from now. You are not asking about how many social invitations you accepted or how impressive you looked in a photo. You are asking whether you built friendships, whether you learned how to manage pressure, and whether you preserved the energy to do things you love. Future-you is not a stranger. You are slowly creating that person through your current environment and routines. That is empowering, but it also calls for humility. Not everyone has the same resources, family support, or access to healthcare. A good health movement should help make healthy choices more possible, not turn them into another reason to blame people.",
    "practice": "Choose a single health behavior that is realistic for you: an extra walk, a consistent bedtime, regular hydration, asking for support, or planning an alcohol-free activity. Then think about how your school or community could make that behavior easier for everyone, not just for the most motivated person. Prevention is strongest when it becomes part of normal life. Health is not a contest to see who can follow the most rules. It is a way to protect your ability to live.",
    "close": "The future of health may be extraordinary. But the future also depends on very unglamorous choices in the present. Let's make those choices easier, smarter, and more inclusive."
  },
  {
    "slug": "emotional-health", "title": "Being Okay Is Not the Same as Looking Okay", "tags": ["mental-health", "emotions", "support"],
    "hook": "You can walk into a room full of people and still feel alone. You can smile in a picture and have a difficult week. We need to get better at remembering that.",
    "idea": "People are surprisingly skilled at presenting the version of themselves they think others want. We post the exciting moment, tell friends we're fine, and sometimes interpret asking for help as failing. But emotional health includes noticing when you need support. Stress, loneliness, and uncertainty deserve real attention. Alcohol can complicate emotional wellbeing, and using it as a regular coping tool may bring added risk. Still, we should not reduce anyone's difficulties to one behavior. If someone is struggling, what they need first is respect, listening, and access to appropriate help, not a public lecture. Prevention needs compassion or it stops being useful. We can discuss the harms of substance use while treating every person involved as someone whose dignity matters.",
    "example": "Imagine a student who appears confident and organized. Everyone assumes they are handling everything. They start missing sleep, withdrawing, and saying yes to things just to avoid feeling isolated. Their friends might not notice because the student is still getting work done. Now imagine one friend asks a real question and stays long enough to hear the answer. That conversation may not fix everything, and it should not replace professional care when needed. But it can interrupt the story that the student has to handle everything alone.",
    "practice": "When you check in with someone, ask something more specific than 'How are you?' Try, 'What has been the hardest part of this week?' or 'Would it help to talk, or would you rather have company?' Respect their answer. If you are the person struggling, identify one trustworthy adult, counselor, professional, or support service you could contact. If there is immediate danger, use emergency support. You do not need to wait for a crisis to take emotional health seriously.",
    "close": "Strong communities do more than applaud achievement. They make space for imperfect human beings. Be the kind of person who makes it a little easier for someone else to tell the truth."
  },
  {
    "slug": "coping-menu", "title": "Build Your Own Coping Menu", "tags": ["coping-skills", "self-regulation", "prevention"],
    "hook": "If I asked you what you do when life gets difficult, could you give me five answers? Or does almost everything come down to one habit?",
    "idea": "We are creatures of habit. Under stress, we often choose the familiar response because it requires the least thought. This can be helpful when the habit is restorative, and less helpful when it only delays dealing with the problem. Relying on alcohol to change mood is one example of a strategy that can introduce its own risks. But simply telling people 'don't' leaves a gap. What do we do instead? That is why I like the idea of a coping menu: a set of options suited to different needs. Some problems require connection. Others require rest, movement, planning, or professional help. No single option works every time. Having several makes it more likely you can choose something helpful when you are not feeling your best.",
    "example": "Let's say you have had a terrible day. A friend suggests distraction. Maybe that is exactly what you need for an hour. But maybe the real issue is that you failed an exam and you have no study plan, or you argued with someone and need to repair a relationship. When every difficult feeling gets the same response, important differences disappear. Think of trying to fix every household problem with a hammer. It might work for a nail, but it is not ideal for a leaking sink. Emotional skills work the same way. The first step is identifying which kind of problem you are dealing with.",
    "practice": "Make four categories in your head. For energy: sleep, food, water, a break. For emotion: music, journaling, breathing, movement. For connection: a friend, family member, counselor, mentor. For action: one small task, an honest conversation, a change of plan. Choose one option from each category that is realistic for you. The next time you feel overwhelmed, do not demand a perfect response. Just pick a tool that matches the problem. If you need professional support, include that in the menu without shame.",
    "close": "Freedom is not being unaffected by difficult feelings. It is having enough tools that one emotion does not decide your entire evening."
  },
  {
    "slug": "family-conversation", "title": "Talking Across Generations About Alcohol", "tags": ["family", "communication", "cultural-context"],
    "hook": "Some topics become difficult the moment we sit across from our parents or another adult. Alcohol can be one of them, because people bring very different experiences to the same conversation.",
    "idea": "In one family, alcohol is a normal part of celebrations. In another, it is connected to painful memories. In a third, nobody talks about it at all. If we want young people to make informed decisions, we have to leave room for those differences without letting silence do all the teaching. Young people need trustworthy information and relationships where honest questions do not automatically lead to punishment or embarrassment. Adults need a chance to share concerns without relying only on fear. There may be disagreement, and some families need outside support to navigate it safely. But a conversation that begins with curiosity will usually reveal more than a speech that begins with an accusation.",
    "example": "Imagine a student asking an adult, 'What would you want me to do if I was at a party and felt unsafe?' That question can open a practical discussion about transport, whom to call, and what to do in an emergency. Compare it with a conversation that stays stuck on whether the teenager is 'good' or 'bad.' The first gives both people information they can use. The second may teach the young person to hide the situation. We can care deeply about prevention while understanding that safety depends on communication as well as rules.",
    "practice": "Try preparing one genuine question for an adult you trust. It might be about how they dealt with peer pressure, what they learned from a mistake, or what support they would provide if you were worried about a friend. You do not have to reveal private information to start. Adults can do their part by listening before responding, staying calm, and knowing where to get reliable advice. A strong conversation gives people a way back to each other when something becomes complicated.",
    "close": "We do not need every family to have the same story. We need more families where the story can be discussed honestly and young people know who will help them."
  },
  {
    "slug": "digital-comparison", "title": "Your Feed Is Not Your Friend Group", "tags": ["social-media", "comparison", "norms"],
    "hook": "If the only evidence you had about student life came from social media, you might think everybody was always out, always confident, and never having a quiet Friday night.",
    "idea": "A feed is a selection process. People upload moments they want others to see, and platforms can amplify content that attracts attention. The result is not a representative sample of anyone's life. This matters when alcohol or party culture becomes especially visible online. A person who sees repeated clips may conclude that heavy social drinking is expected even if their real community is much more varied. Then they feel pressure to live up to a picture made from other people's highlights. Digital literacy means recognizing that visibility is not the same as prevalence. You do not have to reject social media to recognize that it is a distorted mirror.",
    "example": "Imagine you are home on a Friday, working on something you care about. You open your phone for two minutes and see ten clips of people celebrating. Suddenly your quiet evening feels like evidence that your life is behind schedule. But those ten clips could be from different cities, different weeks, and different groups. You have compared one whole evening of your life with a collection of other people's most shareable seconds. That comparison is structurally unfair. It can make you chase an experience you did not even want before opening the app.",
    "practice": "The next time a post triggers fear of missing out, ask, 'What am I actually missing?' Maybe you want connection. Great, message a friend and make a plan. Maybe you want excitement. Find something you genuinely enjoy. Maybe you were perfectly content until the comparison began. Then protect that contentment. Also consider what you post. Does it make room for the many ways people can have fun, or does it quietly suggest there is only one acceptable version of youth?",
    "close": "You deserve a life that feels meaningful from the inside, not just one that looks impressive when reduced to a short video."
  },
  {
    "slug": "student-leadership", "title": "Leadership Is the Behavior People Copy", "tags": ["leadership", "role-models", "school-culture"],
    "hook": "When people think about leadership, they picture titles, microphones, and big speeches. I think most leadership happens when nobody is formally listening.",
    "idea": "Leadership is partly about what becomes normal around you. A student who welcomes a newcomer changes the tone of a room. A team captain who respects a teammate's boundary changes what the team considers acceptable. An organizer who plans an enjoyable alcohol-free event expands people's options. These actions matter because behavior spreads through observation and relationships. We look at people we admire to understand what is possible. That can create pressure, but it can also create permission. If you lead a group, you are not responsible for controlling every member. You are responsible for taking seriously the example you set and the situations you help create.",
    "example": "Imagine a gathering where one popular person makes fun of somebody for declining a drink. Other people may laugh because they do not want to be the next target. Now change one detail. The same popular person says, 'Leave them alone, they said no,' and immediately returns to the conversation. Suddenly respect is the easy option. That short sentence might influence the room more than a long lecture would. Leadership often means using your social position to reduce pressure rather than increase it.",
    "practice": "Ask yourself what gets rewarded in your group. Do people receive attention for being reckless, or for being kind and reliable? When you organize an activity, consider who may feel excluded. When somebody sets a boundary, respect it visibly but casually. When you make a mistake, admit it. If you are part of a student council, club, or ambassador network, build structures that let quieter people contribute. A healthy culture cannot depend on a single charismatic person. It should work even when that person is absent.",
    "close": "The test of leadership is not whether people remember your speech. It is whether they find it a little easier to do the right thing after spending time with you."
  },
  {
    "slug": "listen-and-measure", "title": "Ask Better Questions Before You Build Solutions", "tags": ["community-research", "feedback", "youth-voice"],
    "hook": "What if a school wants to improve student wellbeing but starts by guessing what students need? That sounds efficient until you realize how many important things guessing can miss.",
    "idea": "Prevention programs should begin by listening. Students may face very different challenges: sleep, stress, nutrition, hygiene, social pressure, uncertainty about substances, or not knowing where to find support. A program that assumes everyone needs the same lecture can overlook those differences. Simple, carefully designed questions can help communities understand patterns. But collecting information creates responsibilities. Students deserve to know what is being asked, why it matters, who will see the answers, and whether participation is voluntary. Privacy and consent should be built into the process. Data are not automatically true just because they are in a spreadsheet, and numbers alone cannot explain the full experience behind them. Good community work combines measurement with trust.",
    "example": "Imagine a school where adults believe the main problem is that students do not know the risks of drinking. After listening, they discover many students already know some risks but feel that there are no enjoyable social alternatives and that asking for help is embarrassing. Another school might identify stress and lack of sleep as the concerns students most want addressed. The most valuable change is not proving the adults wrong. It is replacing a generic solution with a more precise one. Listening gives young people influence over the environment they actually live in.",
    "practice": "If you run a survey or listening session, ask a small number of clear, nonjudgmental questions. Avoid collecting identifying information you do not need. Explain who is responsible for keeping answers safe, and do not promise complete anonymity if you cannot provide it. Share useful aggregate findings and show what changed because of the feedback. If people take the time to answer, the program owes them more than a colorful chart. It owes them evidence that their voices mattered.",
    "close": "I want SoberGenZ to be a movement that listens as carefully as it speaks. Real impact begins when we stop assuming and start learning from the people we hope to serve."
  },
  {
    "slug": "build-a-movement", "title": "From One Conversation to a Movement", "tags": ["entrepreneurship", "community", "youth-action"],
    "hook": "Big social changes often begin in a way that looks unimpressive from the outside: a few people around a table noticing a problem and deciding not to ignore it.",
    "idea": "When I think about SoberGenZ, I do not think the job is to walk into a room, deliver a perfect presentation, and disappear. A speech can start a conversation, but a movement has to give people something to do afterward. We need a model where students can teach other students, ask better questions, organize welcoming activities, and adapt good ideas to their communities. That requires structure. A passionate volunteer needs training, clear materials, responsible oversight, and a way to learn from feedback. Without those things, enthusiasm becomes a collection of isolated events. With them, a small project can grow while remaining accountable to the people it serves.",
    "example": "Imagine one student hears a discussion about peer pressure and decides to invite three friends to host an alcohol-free social gathering. One of those friends notices younger students have questions about stress. They invite a counselor to help with a workshop. The next group documents what worked and shares a template with another school. Nothing about that sequence requires a celebrity or a massive budget. It requires initiative, care, and a willingness to improve. Not every idea will work. Some will fail quickly, and we should be honest about that. Progress comes from learning rather than trying to look successful.",
    "practice": "If you want to make a difference, pick a problem narrow enough to act on this month. Identify who experiences it and ask them what help would be useful. Choose one intervention you can deliver responsibly, and decide how you will know whether it helped. Make the activity safe, respectful, and accessible. Then write down what you learned so that somebody else can build on it. Leadership is not a title you wait to receive. It is work you begin doing.",
    "close": "A movement grows when the idea stops belonging to one speaker. My hope is that you leave with something you can adapt, question, and improve, not merely something you can repeat."
  },
  {
    "slug": "transition", "title": "New School, New Freedom, Same Values", "tags": ["transitions", "university", "self-direction"],
    "hook": "A new environment can make you feel as though you have to become a completely new person. New friends, new expectations, new freedom, and suddenly every choice feels like a vote on who you are.",
    "idea": "Transitions are exciting because they give us room to grow. They are difficult because our old routines and support systems may not be immediately available. At a new school or university, you might not know who shares your interests, where to find help, or which social traditions are truly optional. Alcohol may be part of some scenes, but it does not have to determine your social identity. One of the healthiest things you can do when entering a new community is to build more than one way to belong. Join a project, sport, arts group, service initiative, academic circle, or anything that gives you a reason to keep showing up. The goal is not to live in a bubble. It is to have enough genuine connections that any one group's expectations do not control you.",
    "example": "Imagine two students arriving somewhere new. Both desperately want friends. The first says yes to every invitation because they are afraid of being forgotten. The second also says yes often, but they pay attention to which people make them feel respected and which activities leave them energized. They make plans during the day as well as at night. A few weeks later, the second student may still feel awkward sometimes, but they have begun building a network based on shared interests instead of constant performance. That is not an argument for being cautious about every social invitation. It is an argument for choosing the kind of freedom that lasts.",
    "practice": "If you are entering a new phase, make a short plan before the first busy week: two communities you want to explore, one person you could ask for support, one boundary that matters to you, and one way you can have fun that does not depend on alcohol. You can change the plan as you learn. The important part is not waiting until a high-pressure moment to decide every single thing about yourself.",
    "close": "You are allowed to change your interests, style, goals, and friendships. Growth is real. But changing your environment does not mean you have to abandon your judgment."
  },
  {
    "slug": "fomo", "title": "Fear of Missing Out Is a Bad Tour Guide", "tags": ["fomo", "identity", "values"],
    "hook": "Some of our worst decisions begin with a completely understandable fear: what if something amazing happens and I'm not there?",
    "idea": "Fear of missing out can make every invitation feel more important than it is. We imagine the people who attend an event will become closer, collect unforgettable stories, or gain social status. Sometimes that happens. Many times the evening is fairly ordinary. The problem is not wanting experiences. The problem is letting a hypothetical experience overrule what you know about your actual needs. When drinking is framed as a ticket to belonging, FOMO can turn into pressure to participate in something you never independently chose. Freedom includes the option to decline without building a tragic story around the decision. You are not failing at being young because you rest, study, spend time with different people, or choose a different kind of fun.",
    "example": "Picture two invitations on the same night. One is a huge gathering where you know very few people. The other is a small meal with friends you trust. Both could be great. But maybe your brain has already decided the huge gathering must be more important because it sounds more impressive when described later. Now remove the audience that will hear the story. If nobody could post photos and nobody could brag about attending, which event would you genuinely choose? That answer might surprise you. Sometimes we want the story of the event more than the event itself.",
    "practice": "Before accepting an invitation, ask: Am I going because I want to be there, or because I do not want to be absent? If you want to go, make a plan that respects your safety and boundaries. If you don't, choose an alternative and commit to enjoying it rather than spending the whole time checking your phone. Good decisions require making peace with the experiences you did not select. Nobody can attend every event, and a full life is not measured by attendance.",
    "close": "Your life is happening wherever you are, not only wherever the loudest story is being told. Choose experiences because they matter to you."
  },
  {
    "slug": "identity", "title": "Don't Let One Habit Become Your Identity", "tags": ["identity", "self-efficacy", "habits"],
    "hook": "There is a difference between saying 'I made this choice' and saying 'This choice is who I am.' The second sentence can trap people on either side of a decision.",
    "idea": "Human beings are always changing. We learn from friends, from mistakes, from successes, and from the stories we tell ourselves. If someone has made a risky choice, reducing them to that choice can make growth harder. If someone has decided not to drink, reducing them to a stereotype can make belonging harder. A better approach is to talk about values and behavior without turning them into a permanent label. SoberGenZ should never be a place where people are ranked by purity or shamed for their experiences. We can be clear about alcohol-related harms and still be kind. We can encourage prevention and still believe that people deserve support when their lives are complicated.",
    "example": "Imagine someone says, 'I'm just the kind of person who always gives in.' The word 'always' quietly removes their future options. Or imagine someone says, 'You don't drink, so you must never have fun.' That sentence ignores an entire person's personality. In both cases, a label has replaced curiosity. Change begins when someone can say, 'That's what I did, but I get to decide what I do next.' A sense of agency is powerful because it makes improvement possible without pretending the past never happened.",
    "practice": "Try replacing permanent labels with specific descriptions. Instead of 'I'm terrible with pressure,' say 'I found that situation difficult, and I can prepare a response next time.' Instead of 'That person is reckless,' ask what support or information might help them make safer choices. If you have a boundary, explain it in your own words without creating a moral contest. People grow better in communities that combine honest expectations with respect.",
    "close": "You are not a product of one evening, one mistake, or one category other people assign to you. You can keep learning, and the people around you can too."
  },
  {
    "slug": "design-social-spaces", "title": "Build Spaces Where Healthy Choices Feel Normal", "tags": ["event-design", "public-health", "inclusion"],
    "hook": "We spend a lot of time telling individuals to make better choices. I want to ask a different question: what would a room look like if the easier choices were already better ones?",
    "idea": "Individual responsibility matters, but the environment matters too. People are influenced by what is available, convenient, expected, and celebrated. If a youth event has only one obvious way to participate, it should not surprise us when everyone feels nudged in that direction. Schools, clubs, and community groups can widen the menu. Provide genuinely appealing alcohol-free gatherings, accessible support, clear transport plans, and opportunities for people with different interests to connect. Public health should not require every teenager to make a heroic decision every weekend. It should help create conditions in which ordinary decisions are safer and more comfortable.",
    "example": "Imagine walking into an event and seeing groups already talking in closed circles. The only shared activity is a table of drinks. Now imagine walking into an event with a host who introduces newcomers, a creative challenge people can join, snacks, music at a level where conversation is possible, and several choices for what to drink. The second design makes participation easier without requiring a personality transplant. In both rooms, individuals remain responsible for themselves. But one room has done much more work to make belonging possible.",
    "practice": "If you organize a gathering, draw the experience from the perspective of the person who arrives alone. What do they see in the first thirty seconds? How do they join a conversation? Can someone decline an offer without attracting attention? Is there a clear way to ask for help? Is the event appealing if a person doesn't drink? Treat these as design questions, not afterthoughts. Then ask for feedback and actually use it.",
    "close": "Healthy culture is something we can build together. The goal is not to create a perfect community overnight. It is to make the next version of the room better than the last one."
  }
]

TOPICS.extend([
  {
    "slug": "nutrition-and-energy", "title": "Energy Is More Than Motivation", "tags": ["nutrition", "wellbeing", "everyday-health"],
    "hook": "We talk endlessly about motivation, yet some days the reason everything feels difficult is simpler: we have not looked after the basic needs of our bodies.",
    "idea": "Nutrition, hydration, movement, rest, and mental wellbeing are connected to how we feel and function. There is no single meal or routine that guarantees good health, and people's needs differ. But the basics matter. If you arrive at school exhausted, without having eaten enough, and with a difficult week ahead, it may be much harder to handle stress or stay attentive. Substance-use education can become strangely narrow when we discuss only what to avoid and never what helps people thrive. A serious prevention program should care about the whole person. We should build habits, services, and environments that support everyday wellbeing, while recognizing that food insecurity, health problems, and other barriers are not solved by simply telling people to try harder.",
    "example": "Imagine someone trying to study for an exam at the end of an exhausting day. They interpret their frustration as personal failure. In reality, they may need a meal, rest, a break, or help with something they cannot manage alone. Now imagine a school that asks students about the obstacles they face rather than assuming that low energy means low discipline. The school might discover that a timetable, a lack of safe drinking water, or limited access to support is part of the story. Better questions can lead to more useful solutions.",
    "practice": "Choose a basic need to pay attention to over the next few days. Notice when you feel most alert and what routines support that feeling. Avoid using one person's body or diet as a standard for everybody. If you work with students, ask what resources are actually available before recommending a habit. Consider a community project that improves access to water, a welcoming activity that includes nutritious food, or a peer conversation about realistic routines. Prevention becomes credible when it takes ordinary constraints seriously.",
    "close": "Looking after your wellbeing does not have to be glamorous to matter. Sometimes the best support for a big ambition is making the everyday foundations stronger."
  },
  {
    "slug": "pause-before-action", "title": "The Power of a Five-Second Pause", "tags": ["impulse-control", "self-regulation", "neuroscience"],
    "hook": "I want to give you a tiny experiment. Think of the last message you almost sent while annoyed. How different might the conversation have been if you had waited five seconds?",
    "idea": "A pause is not a guarantee of a good decision, but it can create space between an impulse and an action. Our brains continuously balance emotion, attention, learned habits, and goals. When we are excited or under pressure, the most immediate option can seem much more attractive than the one we would choose calmly. Alcohol can further impair judgment, which is one reason preparation matters before entering high-pressure situations. The most useful lesson is not that emotion is an enemy. Emotions provide information. It is that a feeling and a decision are different things. You can be nervous without agreeing. You can be excited without acting immediately. You can feel excluded and still choose a response that protects your future.",
    "example": "Imagine receiving an invitation with the message, 'Everybody's going, don't be lame.' Your instinct may be to say yes before finding out where the event is or how you will get home. Now imagine you pause and ask three questions. Do I want to go? Do I know the plan? Can I leave if I need to? Those questions do not drain the excitement out of life. They help you participate on your own terms. The pause transforms a reflex into a choice. We can practice that same skill before reacting to an insult, joining a rumor, or making a purchase we cannot afford.",
    "practice": "Practice the sequence: notice, name, choose. Notice the rush of urgency. Name what you are feeling: anxious, curious, frustrated, eager to impress. Then choose one action that reflects what matters to you. It might be asking a question, saying no, calling a friend, or simply waiting until you have more information. Start with low-stakes situations, like responding to a group chat. Skills are easier to use under pressure when they are familiar beforehand.",
    "close": "Five seconds will not solve every problem. But sometimes a few seconds are enough to remember that you are the person who gets to decide what happens next."
  },
  {
    "slug": "respect-not-stigma", "title": "Prevention Without Shame", "tags": ["stigma", "compassion", "substance-education"],
    "hook": "A prevention message can be scientifically accurate and still fail if the people hearing it feel judged, embarrassed, or dismissed.",
    "idea": "People who have questions or difficult experiences involving alcohol need room to ask for help. If every conversation divides the world into good people and bad people, those who most need reliable information may be the least likely to speak. We can state clearly that alcohol carries risks, that young people deserve protection from those risks, and that safer choices matter. We can do all of that without humiliating anybody. Substance-related problems can be complex and may require professional assessment or treatment. A school session should never pretend that a few motivational lines replace that support. What we can do is increase understanding, reduce fear of asking for assistance, and make accurate resources easier to find.",
    "example": "Imagine two presentations. In the first, a speaker asks students to raise their hands and publicly admit experiences they may not want to share. In the second, students can ask anonymous questions, hear clear information, and learn where to seek confidential help. Which room is more likely to produce an honest conversation? The second room does not require the presenter to approve of risky behavior. It requires the presenter to respect the audience's dignity. Trust is not a bonus in prevention work. It is part of how the work becomes possible.",
    "practice": "When you speak about someone facing a challenge, describe the behavior or situation rather than treating it as the person's entire identity. Do not demand personal disclosures in group settings. Provide pathways to qualified support, and follow local safeguarding requirements when working with minors. If a friend tells you something worrying, listen seriously, avoid promising secrecy you cannot safely keep, and encourage help from appropriate adults or professionals. Our aim is to make the next safe step easier, not the person smaller.",
    "close": "The strongest prevention message is both clear and humane. We can protect young people without making them afraid to tell us the truth."
  },
  {
    "slug": "future-self", "title": "What Would Future You Thank You For?", "tags": ["goals", "future-self", "habit-building"],
    "hook": "Let's do something unusual. For a moment, imagine you are writing a thank-you letter to yourself, but the person receiving it is ten years older.",
    "idea": "We often talk about long-term goals as if they are separate from daily life. We want to be healthy, respected, capable, and surrounded by people we trust, yet we make choices when we are tired or distracted without connecting them to those goals. The future can feel abstract. One way to make it more concrete is to think about what an older version of yourself would value: attention, friendships, good memories, skills, opportunities, and the ability to recover when life gets hard. Avoiding unnecessary alcohol-related harms can support that future, but so can sleep, learning, movement, and asking for help. It is not about demanding perfection. It is about noticing that small choices form the environment in which big possibilities grow.",
    "example": "Imagine you are deciding whether to stay in a setting where you are uncomfortable because you don't want to disappoint a group. Future-you cannot send you a message from ten years ahead. But you can borrow their perspective. Would they be impressed that you ignored your own discomfort for another hour? Or would they be grateful that you went home safely, kept a friendship with somebody respectful, and woke up able to do the things that matter to you? The answer might differ by situation. The useful skill is remembering that the person who handles the consequences is still you.",
    "practice": "Write a sentence beginning, 'In ten years, I hope I am someone who...' Finish it with a quality rather than a status symbol: someone who keeps promises, knows when to ask for help, protects friends, or follows through on meaningful work. Then choose a decision you can make this week that supports that quality. The action should be small enough to be believable. You are practicing a direction, not signing a contract for a flawless future.",
    "close": "Your future is not predetermined, and circumstances matter. But you have influence over it. Use that influence to build a life that a younger version of you would feel safe growing into."
  },
])

assert len(TOPICS) == 30, len(TOPICS)

# Four delivery environments, 30 distinct topics each, make 120 complete talks.
AUDIENCES = [
    {
      "key": "middle_school", "label": "Younger secondary students", "age": "12-14", "context": "school assembly / classroom",
      "open": "Good morning, everyone. I'm speaking with you today through SoberGenZ. Some of you may have heard older students talk about parties or drinking and wondered what those conversations have to do with you. You do not need to have any experience with alcohol to be part of this discussion. We are here to build a skill before you are expected to use it: thinking for yourself in a room full of other people. There will be no requests to share personal stories in front of the class. You can take part by thinking, listening, or asking a general question. The goal is to leave with language you can actually use outside this room.",
      "bridge": "At your age, many important social moments happen in places adults might consider ordinary: a lunch table, a birthday, a class group chat, the corridor after school. Someone makes a joke, somebody tries to impress the group, and a small decision suddenly feels huge. That's why I don't want you to hear today's ideas as a lecture about a distant future. Think about the moments you already face: being dared to say something unkind, being pushed to join an activity, or staying quiet when a friend needs support. The same decision skills apply. You can practice them now with situations that are safer and more familiar.",
      "reflect": "Let me ask you a question, and you can answer silently. Think of a person your age you respect. What makes them impressive? Is it that they copy the loudest person in the room, or that they seem comfortable doing what they believe is right? Take ten seconds to picture one specific action you admired. Maybe they included a new student, stood up for a friend, or admitted a mistake. That action is what courage looks like in everyday life. Whatever your answer, keep it in mind when we talk about making choices.",
      "finish": "Before I finish, pick one sentence you can take from this room and use this week. It might be 'I'm good, thanks,' 'What do you want to do instead?' or 'Are you okay?' You don't need to make a dramatic announcement. Try it once where it matters. Thank you for listening, and remember that a thoughtful choice is something you can practice long before a difficult situation arrives."
    },
    {
      "key": "high_school", "label": "Older secondary students", "age": "15-18", "context": "secondary school workshop",
      "open": "Hi, everyone. I'm here with SoberGenZ, and I want this to feel more like a real conversation than another adult-style warning speech. You already make complicated choices. You manage coursework, friendships, family expectations, relationships, and a social world that can move very quickly. The point today is not to assume you're reckless, and it certainly isn't to pretend that every person in this room has the same experience. It's to look at what actually shapes our decisions and how we keep control over them. You won't have to disclose anything personal. The questions I ask are for reflection, not for a public confession.",
      "bridge": "There's a particular kind of pressure that comes with being old enough to want independence and young enough for other people to constantly define what independence should look like. One group might expect you to be adventurous. Another might expect you to be perfect. Neither group gets to write the entire definition of maturity for you. What matters is whether you can consider a consequence, set a boundary, and still build a full social life. The choices we discuss today are not only about alcohol. They touch confidence, loyalty, ambition, and what kind of friends we want to be.",
      "reflect": "I want you to picture a Friday evening six months from now. You have an invitation, you're tired, and you have a genuine reason to feel torn. What information would help you decide well? Think about who will be there, whether you feel comfortable, what you need the next day, and how you would leave if your plans changed. Now ask yourself whether you usually consider those things before or after saying yes. There's no perfect answer, but there is a skill in making a decision before social momentum makes it for you.",
      "finish": "I'll end with one challenge: choose one thing you currently do because it's expected, and ask yourself whether you'd choose it without an audience. You don't have to change anything just to prove a point. I just want the answer to be yours. If you remember one idea from SoberGenZ, let it be that you can have meaningful friendships, spontaneity, and excitement without surrendering the right to decide what you're comfortable with. Thank you."
    },
    {
      "key": "university", "label": "University students and new adults", "age": "18-22", "context": "campus orientation / student gathering",
      "open": "Thanks for having me. I'm speaking through SoberGenZ, and I want to start with the freedom that comes when you leave a familiar environment. For some people, university means a new city, new friends, and being able to make decisions without checking with family first. That can be incredible. It can also create pressure to prove that you're living the kind of college experience you see in movies or online. My goal isn't to prescribe one social life. It's to ask how we build a life that's exciting and genuinely ours, while taking health, safety, and friendships seriously.",
      "bridge": "On a campus, a single weekend can seem strangely symbolic. People talk about who went where, who knows whom, and which event everybody supposedly attended. Yet the best part of university is that there are hundreds of possible communities. You can find people through research, sports, music, service, entrepreneurship, and quiet conversations over food. If one social setting pressures you to act against your values, it doesn't mean you're failing at campus life. It might mean you haven't yet discovered the other spaces where you fit more naturally. Freedom is not the absence of boundaries; it's the ability to choose them.",
      "reflect": "Here's a short thought experiment. Imagine the next ten weekends on campus. You cannot say yes to every invitation and still have time to sleep, study, train, work, and stay close to the people you care about. So you have to choose. What kind of memories would you actually like to have at the end of the term? A few spectacular events? A solid group of friends? Progress on a project? Ideally some mix. The point is that saying no to one thing can be saying yes to something else that matters more. That's what makes intentionality useful, not restrictive.",
      "finish": "As you leave, I hope you'll do more than think about what to avoid. Think about what you want to create. Host something inclusive, make room for a friend who doesn't drink, check that people can get home safely, or build a group around something you love. You have an unusual amount of influence over the culture of the communities you're joining. Use that influence thoughtfully. Thanks for being here."
    },
    {
      "key": "ambassadors", "label": "Student leaders, educators, and youth ambassadors", "age": "16+", "context": "ambassador training / community leadership session",
      "open": "Hello, and thank you for giving your time to this SoberGenZ session. Some of you help run school clubs, teach, lead student groups, or organize events. That means the decisions you make can affect more than one person. I want to approach this as a working session about what effective prevention sounds like and how we can build environments that support good choices. We should be willing to talk about alcohol-related harms clearly. We should also be willing to listen, adapt, admit uncertainty, and protect the dignity of the students we work with. Good intentions are a start, not a method.",
      "bridge": "When you're a leader, the challenge is to turn an individual message into an experience people can actually use. A student can hear an inspiring talk and still face the same peer pressure that evening. So ask what changes around them afterward. Do they have language for setting boundaries? Are there social alternatives? Do they know where to get help? Is a trusted adult available? Can quieter students participate without disclosing private experiences? These questions make prevention more practical and help us avoid thinking that a dramatic presentation is the same thing as lasting impact.",
      "reflect": "For a moment, picture the last event or workshop you helped organize. Now think of the student who sat at the back and said nothing. Did the design of the session help that person feel safe and included, or did all the attention go to whoever was already confident? This isn't a criticism. It's a design test. We should measure success partly by what becomes possible for the person who didn't arrive with social capital. That means asking for feedback, working within safeguarding requirements, and making sure our actions match the respectful language we use on stage.",
      "finish": "I'll leave you with a specific assignment. Choose one part of your school or group culture you can improve within thirty days. Talk to the people affected, involve the appropriate adults or professionals, and define a realistic way to learn whether the change helped. Document the process so another group can build on it. SoberGenZ should stand for responsible action, not just confident words. Thank you for the work you do for young people."
    }
]

# Distinct framing paragraphs diversify how speakers introduce a given theme.
FRAMES = [
    "Before we get into the main idea, I want to make one distinction. Information is not the same as judgment. I'm not here to inspect anybody's private decisions or ask who has and hasn't done something. I'm here because we make better choices when we have accurate information, supportive people, and a chance to think before the pressure arrives. If there is a detail you disagree with, question it. If there is a concept you recognize from your own life, hold on to it. This should be useful long after the chairs in this room have been put away.",
    "Part of the reason I care about this work is that we often underestimate young people. We give them slogans when they deserve explanations. We give them lists of rules when they also need social skills and trustworthy relationships. So today, I want to connect the science to everyday behavior. You do not have to memorize terminology. You do have to get curious about why a choice that seems simple from a distance can feel complicated when you are standing in the middle of it.",
    "I also want to make clear what this session cannot do. One talk does not fix a stressful environment, replace medical advice, or solve every challenge a student might face. But a talk can change the next conversation. It can give someone language for a boundary, remind a group that they have alternatives, or encourage a person to seek proper support. Those are real, practical goals. We don't need to exaggerate our power to make the effort worthwhile.",
    "People sometimes think the goal of prevention is to make life smaller: fewer invitations, fewer experiences, less fun. I see it differently. The point is to expand choice. It's to make space for students who have different values, cultures, ambitions, and comfort levels. When everyone feels forced into a single version of being young, the group loses something. When people can participate without pretending to be someone else, there is more room for genuine connection. Keep that idea in the background as we explore today's question."
]

QUESTION_VARIANTS = [
    "I want you to take five quiet seconds here. Think about how you would explain this idea to a friend who wasn't in the room. Try to do it without using a big scientific word or repeating my phrasing. What would you say in ordinary language? If an idea is going to affect your decisions, it needs to survive outside a classroom. That's the standard I want us to use. If your explanation feels awkward at first, that's completely normal. Practice helps us turn information into something available when it matters.",
    "Here's a second way of testing the idea. Imagine you disagree with part of what I've said. What would a thoughtful question sound like? It might be about how people behave in different cultures, what the science really supports, or why some choices seem harder than others. Asking those questions is a sign of engagement, not disrespect. We want people to develop judgment, and judgment improves through careful questioning. A prevention movement that cannot tolerate honest questions won't be a very useful one.",
    "There is another person I want you to consider: the student who is listening to this and thinks, 'That's easy for someone else to say.' They might have a difficult home life, a complicated social circle, or fewer options for getting home safely. If we want our advice to be genuinely useful, we have to notice those constraints. We can encourage personal responsibility while recognizing that not everybody starts from the same circumstances. A strong community makes safer choices easier and provides support when someone needs more than a motivational sentence.",
    "Let's turn this around for a moment. Instead of asking how you personally should act, ask what you could change for the next person in your situation. Could you make it easier for a friend to decline something? Could you be the person who invites someone new? Could you check in without judgment, or organize an activity where participation doesn't depend on drinking? Sometimes the most sustainable form of self-confidence is not simply resisting pressure but reducing it for everybody around you."
]

SPEECH_LINKS = [
    "This may sound like a small distinction, but small distinctions are exactly what shape behavior in real settings. When we remove the drama, we are left with a series of decisions that can be prepared for, discussed, and improved. None of us will get every decision right. That should make us more interested in learning, not less.",
    "The reason this topic matters is that it lives at the intersection of science and culture. You can understand a health risk perfectly and still struggle when the surrounding environment rewards a different choice. That's why I keep coming back to the people, routines, and spaces around us, not just individual willpower.",
    "I want to resist two extreme stories. One says young people are incapable of good judgment and need only orders. The other says that because risk is part of life, understanding it doesn't matter. Neither helps us. Good education respects people's agency while giving them tools and realistic information.",
    "As we discuss this, notice the gap between what sounds impressive and what works. A dramatic promise is easy to make. A simple plan, a respectful friend, or an accessible support system might look less exciting, but those are often what people can use when a real decision arrives."
]

assert len(AUDIENCES) == 4
assert len(FRAMES) == len(QUESTION_VARIANTS) == len(SPEECH_LINKS) == 4

CONTEXT_LINES = {
    "middle_school": [
      "If this sounds abstract, put the idea into a school lunch break. The decisions in front of you may seem smaller, but the habit of noticing pressure begins there.",
      "Think about a group project where one person decides for everyone. The skill we're discussing also helps you make room for quieter classmates.",
      "Imagine a birthday party where you want to fit in but also want to go home feeling proud of how you treated people. That is a useful place to practice.",
      "Sometimes the first step is simply telling a trusted adult that a situation feels confusing. Being independent and asking for help can happen together."
    ],
    "high_school": [
      "Think about a school formal, a birthday, or the hours after an exam. A social plan can change quickly, so deciding what matters beforehand is valuable.",
      "Imagine a group chat where the first response seems to decide everybody else's plans. One question from you can reveal the options nobody has mentioned.",
      "For anyone balancing coursework and a social calendar, remember that the person who wakes up tomorrow gets a vote in tonight's plans too.",
      "A real test of confidence comes when your preferred choice is less popular. It still deserves to be considered seriously."
    ],
    "university": [
      "Imagine the first few weeks on campus, when the same people appear at every event and it can feel like one group represents everybody. It doesn't.",
      "Think about a student club night or a gathering after an exam. You can be present, friendly, and engaged without making every decision the group's decision.",
      "There will always be one more invitation, one more event, and one more opportunity to miss out on something. Choose with the bigger picture in mind.",
      "When you arrive somewhere new, the quiet decision to find people who respect you can matter more than being seen in the loudest room."
    ],
    "ambassadors": [
      "Think about a workshop where the audience understands the facts but lacks a way to use them. Our job is to close that gap through practice and support.",
      "Consider the student who never volunteers an answer. How can the structure of your event make participation safer for that person?",
      "If you are planning an outreach session, build a route from knowledge to action: one idea, one practical skill, one trustworthy place to seek help.",
      "A successful ambassador is not the person with the most dramatic speech. It is the person whose audience leaves with something usable."
    ]
}


def duration_minutes(word_count: int) -> int:
    return round(word_count / 128)


def make_record(topic_number: int, audience_number: int) -> dict:
    topic = TOPICS[topic_number]
    audience = AUDIENCES[audience_number]
    shift = (topic_number * 3 + audience_number) % 4
    parts = [
        ("greeting", audience["open"]),
        ("opening_question", topic["hook"]),
        ("why_we_are_here", FRAMES[shift]),
        ("science_and_context", topic["idea"]),
        ("audience_connection", audience["bridge"]),
        ("real_world_example", topic["example"]),
        ("contextual_example", CONTEXT_LINES[audience["key"]][(topic_number + audience_number) % 4]),
        ("reflection_question", QUESTION_VARIANTS[(shift + 1) % 4]),
        ("connecting_the_dots", SPEECH_LINKS[(shift + 2) % 4]),
        ("practical_actions", topic["practice"]),
        ("audience_reflection", audience["reflect"]),
        ("core_takeaway", topic["close"]),
        ("call_to_action_and_thanks", audience["finish"]),
    ]
    transcript = "\n\n".join(p for _, p in parts)
    number = topic_number * 4 + audience_number + 1
    words = len(re.findall(r"\b[\w’-]+\b", transcript))
    return {
        "id": f"SGZ-{number:03d}",
        "organization": ORG,
        "speaker_role": "SoberGenZ founder / presenter",
        "title": f"{topic['title']} | {audience['label']}",
        "topic_id": topic["slug"],
        "primary_topic": topic["title"],
        "audience": audience["label"],
        "audience_key": audience["key"],
        "age_range": audience["age"],
        "setting": audience["context"],
        "language": "en",
        "tags": list(dict.fromkeys(topic["tags"] + [audience["key"], "SoberGenZ", "alcohol-prevention", "youth-wellbeing"])),
        "word_count": words,
        "estimated_delivery_minutes": duration_minutes(words),
        "sections": [{"section": key, "text": value} for key, value in parts],
        "transcript": transcript,
    }


def main() -> None:
    rows = [make_record(i, j) for i in range(len(TOPICS)) for j in range(len(AUDIENCES))]
    assert len(rows) == 120
    assert len({r["id"] for r in rows}) == 120
    assert len({r["transcript"] for r in rows}) == 120
    assert all(r["transcript"].startswith(("Good morning", "Hi,", "Thanks", "Hello")) for r in rows)
    assert all(r["transcript"].endswith(("arrives.", "you.", "here.", "people.")) for r in rows)
    assert all(700 <= r["word_count"] <= 1250 for r in rows), [(r["id"],r["word_count"]) for r in rows if not (700 <= r["word_count"] <=1250)]

    jsonl_path = ROOT / "sobergenz_120_speeches.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    json_path = ROOT / "sobergenz_120_speeches.json"
    with json_path.open("w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

    # Five semantically coherent chunks per speech, suitable for embeddings/RAG.
    chunk_groups = [
        (0, 3), (3, 5), (5, 8), (8, 10), (10, 13)
    ]
    with (ROOT / "sobergenz_speech_chunks.jsonl").open("w", encoding="utf-8") as f:
        for row in rows:
            for ci, (lo, hi) in enumerate(chunk_groups, 1):
                chunk_sections = row["sections"][lo:hi]
                chunk = {
                    "chunk_id": f"{row['id']}-C{ci:02d}",
                    "speech_id": row["id"],
                    "title": row["title"],
                    "topic_id": row["topic_id"],
                    "audience_key": row["audience_key"],
                    "language": row["language"],
                    "tags": row["tags"],
                    "section_names": [p["section"] for p in chunk_sections],
                    "text": "\n\n".join(p["text"] for p in chunk_sections),
                }
                f.write(json.dumps(chunk, ensure_ascii=False, separators=(",", ":")) + "\n")

    db_path = ROOT / "sobergenz_120_speeches.sqlite"
    if db_path.exists():
        db_path.unlink()
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript("""
      CREATE TABLE speeches (
        id TEXT PRIMARY KEY,
        organization TEXT NOT NULL,
        speaker_role TEXT NOT NULL,
        title TEXT NOT NULL,
        topic_id TEXT NOT NULL,
        primary_topic TEXT NOT NULL,
        audience TEXT NOT NULL,
        audience_key TEXT NOT NULL,
        age_range TEXT NOT NULL,
        setting TEXT NOT NULL,
        language TEXT NOT NULL,
        tags_json TEXT NOT NULL,
        word_count INTEGER NOT NULL,
        estimated_delivery_minutes INTEGER NOT NULL,
        transcript TEXT NOT NULL
      );
      CREATE TABLE speech_sections (
        speech_id TEXT NOT NULL REFERENCES speeches(id),
        section_order INTEGER NOT NULL,
        section_type TEXT NOT NULL,
        text TEXT NOT NULL,
        PRIMARY KEY (speech_id, section_order)
      );
      CREATE INDEX idx_speeches_topic ON speeches(topic_id);
      CREATE INDEX idx_speeches_audience ON speeches(audience_key);
      CREATE VIRTUAL TABLE speech_search USING fts5(
        id UNINDEXED, title, primary_topic, audience, transcript, tokenize='unicode61'
      );
    """)
    for row in rows:
        con.execute(
          "INSERT INTO speeches VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          (
            row["id"], row["organization"], row["speaker_role"], row["title"],
            row["topic_id"], row["primary_topic"], row["audience"],
            row["audience_key"], row["age_range"], row["setting"],
            row["language"], json.dumps(row["tags"]), row["word_count"],
            row["estimated_delivery_minutes"], row["transcript"],
          ),
        )
        con.execute(
          "INSERT INTO speech_search (id,title,primary_topic,audience,transcript) VALUES (?,?,?,?,?)",
          (row["id"], row["title"], row["primary_topic"], row["audience"], row["transcript"])
        )
        for i, section in enumerate(row["sections"]):
            con.execute("INSERT INTO speech_sections VALUES (?,?,?,?)",
                        (row["id"], i, section["section"], section["text"]))
    con.commit()
    assert con.execute("SELECT count(*) FROM speeches").fetchone()[0] == 120
    assert con.execute("SELECT count(*) FROM speech_sections").fetchone()[0] == 120 * 13
    sample = con.execute("SELECT id, title FROM speech_search WHERE speech_search MATCH 'dopamine' LIMIT 5").fetchall()
    assert sample, "full-text search test failed"
    con.close()

    stats = {
        "total_speeches": len(rows),
        "unique_topics": len(TOPICS),
        "audiences": len(AUDIENCES),
        "total_words": sum(r["word_count"] for r in rows),
        "min_words": min(r["word_count"] for r in rows),
        "max_words": max(r["word_count"] for r in rows),
        "estimated_minutes_total": sum(r["estimated_delivery_minutes"] for r in rows),
        "ids": [rows[0]["id"], rows[-1]["id"]],
        "search_test": sample,
    }
    (ROOT / "statistics.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
